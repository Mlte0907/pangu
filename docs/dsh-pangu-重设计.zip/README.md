﻿# 盘古仪表盘重设计 · 交付包（方向 A / B 双方案）

日期：2026-09-17 · 对象：dsh-pangu v1.4.0（DSH web「盘古」标签页 + 侧边栏）
基线勘察：192.168.5.8 只读采样（盘古 v0.3.0 API + config.json + module_registry + drawers.json + knowledge_graph.db）

## 包内文件

| 文件 | 说明 |
|---|---|
| pangu-redesign-sample.html | 方向 A 样品 ·「记忆是有季节的」暖纸叙事流（新侧边栏体征帧 + 概览/星系/结晶/管理四标签页） |
| pangu-redesign-sample-B.html | 方向 B 样品 ·「全景观测台」恒定深色仪器盘（六区能力墙，19 模块 449 工具全量展示） |
| 重设计方案.md | 方向 A 方案：勘察结论 / 痛点 / 概念 / 信息架构 / 视觉系统 / 5 步落地路径 |
| 重设计方案-B.md | 方向 B 方案：概念反转 / 六区详解 / A-B 取舍表 / 组合落地建议 |
| .shots/ | 桌面 + 移动端渲染验证截图 |

## 勘察要点（两方案共同依据）

- 盘古 v0.3.0：Wing→Room→Drawer 宫殿 + ONNX 混合检索（向量 0.6 + FTS5 4.0 + RRF k=60 + 激活扩散 depth3/λ0.6）+ 艾宾浩斯遗忘（base .95 / floor .15 / 夜间 .5）+ 睡眠巩固（03:00–05:00）+ 四层记忆栈 L0–L3（1000–3000t）
- 现插件 lib/client.js 1493 行，挂点 sidebar.footer.action / conversation.view / settings.section，accent 紫 #6c5ce7
- 真实库况：132 条记忆（23 加密 / 18 待审 / decay 均 0.17）、KG 22 实体 8 关系、向量索引 134、Token 90456、检索 0 命中、巩固从未运行
- 工具全景：19 模块 449 工具（core 7/131 · optional 11/198 · experimental 1/120），白名单 30
- 事件流：/ws 8 类（memory_create/update/delete/recall, wiki_update, kg_update, system_status, heartbeat）

## 落地建议

A+B 组合：A 为默认标签页（日常），B 为「观测台」第二标签页（巡检/演示）。
落地路径见两份方案文档的 PR 章节；动手前需用户确认方向。